/*Implementa��o de uma fun��o equivalente ao strcpy (s1, s2)*/

#include <stdio.h>
#include <string.h>

void strcpyAL2 (char s1[], char s2[])
{
	int i;
	
	for (i=0;s2[i];i++)
	{
		s1[i] = s2[i];
	}
	
	s1[i] = '\0';
}

int main ()
{
	char str1[20], str2[20];
	
	printf ("Entre com uma palavra: ");
	gets (str2);
	
	strcpyAL2 (str1,str2);
	printf ("str1 = %s\nstr2 = %s", str1, str2);
}
