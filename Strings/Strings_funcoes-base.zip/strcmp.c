/*Implementa��o de uma fun��o equivalente ao strcmp (s1, s2)*/

#include <stdio.h>
#include <string.h>

int strlenAL2 (char palavra[])
//int strlenAL2 (char *palavra)
{
	int i;
	
	for (i=0;palavra[i];i++);
	
	return i;
}

int strcmpAL2 (char s1[], char s2[])
{
	int i, tam1 = strlenAL2 (s1), tam2 = strlenAL2 (s2);
	
    for (i=0;s1[i] && s2[i];i++)
	{
		if (s1[i] < s2[i])
		{
			return -1;
		}
		else
		{
			if (s1[i] > s2[i])
			{
				return 1;
			}
		}
	}
	
	if (tam1 > tam2)
	{
		return 1;
	}
	else
	{
		if (tam1 < tam2)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
}

int main ()
{
	char str1[30], str2[20];
	int resp;
	
	printf ("Entre com a primeira palavra: ");
	gets (str1);
	
	printf ("Entre com a segunda palavra: ");
	gets (str2);
	
	resp = strcmpAL2 (str1,str2);
	
	printf ("str1 = %s\nstr2 = %s\n\nresp = %d", str1, str2, resp);
}
