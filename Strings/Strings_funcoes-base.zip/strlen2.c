/*Implementa��o de uma fun��o que determine o n�mero de caracteres de uma string s.
Ou seja, uma fun��o com o mesmo objetivo de STRLEN*/

#include <stdio.h>
#include <string.h>

int strlenAL2 (char palavra[])
//int strlenAL2 (char *palavra)
{
	int i;
	
	for (i=0;palavra[i];i++);
	
	return i;
}

int main ()
{
	char nome[20];
	int quant;
	
	printf ("Entre com seu nome: ");
	//scanf ("%s", nome);        p�ra a leitura quando encontrar um espa�o 
	//scanf ("%[^\n]s", nome);   p�ra a leitura quando encontrar o \n
	gets (nome);
	
	quant = strlenAL2 (nome);
	printf ("H� %d caracteres na string %s", quant, nome);
}
