/*Implementa��o de uma fun��o equivalente ao strcat (s1, s2)*/

#include <stdio.h>
#include <string.h>

int strlenAL2 (char palavra[])
//int strlenAL2 (char *palavra)
{
	int i;
	
	for (i=0;palavra[i];i++);
	
	return i;
}

void strcatAL2 (char s1[], char s2[])
{
	int i, j;
	
	for (i=strlenAL2(s1), j=0 ; s2[j] ; i++, j++)
	{
		s1[i] = s2[j];
	}
	
	s1[i] = '\0';
}

int main ()
{
	char str1[30], str2[20];
	
	printf ("Entre com a primeira palavra: ");
	gets (str1);
	
	printf ("Entre com a segunda palavra: ");
	gets (str2);
	
	strcatAL2 (str1,str2);
	
	printf ("str1 = %s\nstr2 = %s", str1, str2);
}
