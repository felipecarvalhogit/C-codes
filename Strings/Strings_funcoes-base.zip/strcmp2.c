/*Implementa��o de uma fun��o equivalente ao strcmp (s1, s2)*/

#include <stdio.h>
#include <string.h>

int strcmpAL2 (char s1[], char s2[])
{
	int i;
	
    for (i=0;s1[i] && s2[i] && (s1[i] == s2[i]);i++);
	
	return s1[i] - s2[i];
}

int main ()
{
	char str1[30], str2[20];
	int resp;
	
	printf ("Entre com a primeira palavra: ");
	gets (str1);
	
	printf ("Entre com a segunda palavra: ");
	gets (str2);
	
	resp = strcmpAL2 (str1,str2);
	
	printf ("str1 = %s\nstr2 = %s\n\nresp = %d", str1, str2, resp);
}
