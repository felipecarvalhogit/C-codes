//copiar um arquivo para outro
#include <stdio.h>

//retorna 0 ou 1
int copiarArquivo (char origem[], char destino[])
{
	FILE *arq1, *arq2; 
	char caracter;

	arq1 = fopen (origem, "r");   
	arq2 = fopen (destino, "w");   
	
	//if ((arq1 == NULL) || (arq2 == NULL))
	if ((!arq1) || (!arq2))
	{
		return 0;
	}
	else
	{
		while (!feof(arq1))
		{
			fscanf (arq1, "%c", &caracter);
			fprintf (arq2, "%c", caracter);
		}
		
		fclose (arq1);	
		fclose (arq2);
		
		return 1;	
	}		
}


//retorna a quantidade de remo��es
int remover (char nomeArq[], int numero)
{
	FILE *arq, *tmp; 
	int num, cont=0;

	arq = fopen (nomeArq, "r");   
	tmp = fopen ("temp.txt", "w");
	
	if ((!arq) || (!tmp))
	{
		return -1;
	}
	else
	{
		while (!feof(arq))
		{
			fscanf (arq, "%d\n", &num);
			if (num != numero)
			{
				fprintf (tmp, "%d\n", num);
			}
			else
			{
				cont++;
			}
		}
		
		fclose (arq);	
		fclose (tmp);
		
		copiarArquivo ("temp.txt", nomeArq);
		
		return cont;	
	}		
}

int main ()
{
	char nome[20];
	
	int numero, quant;
	
	printf ("Entre com o nome do arquivo: ");
	scanf ("%s", nome);
	
	printf ("Entre com o numero a ser removido: ");
	scanf ("%d", &numero);
	
	quant = remover (nome, numero);
	
	if (quant == -1)
	{
		printf ("Erro na abertura do arquivo!");
	}
	else
	{
		printf ("Foram removidas %d ocorr�ncias de %d", quant, numero);
	}
}
