//exibe na tela o conte�do de um arquivo
#include <stdio.h>

//retorna 0 se n�o conseguir manipular o arquivo; ou 1, caso contr�rio
int exibeArquivo (char nomeArq[])
{
	FILE *arq;  //declarando o arquivo
	char caracter;

	arq = fopen (nomeArq, "r");   //abrindo o arquivo para leitura
	
	if (arq == NULL)
	{
		return 0;
	}
	else
	{
		while (!feof(arq))
		{
			fscanf (arq, "%c", &caracter);
			printf ("%c", caracter);
		}
		
		fclose (arq);	
		return 1;	
	}		
}

int main ()
{
	char nomeArq[20];
	
	//perguntando ao usu�rio o nome do arquivo
	printf ("Entre com o nome do arquivo: ");
	scanf ("%s", nomeArq);
	
	if (exibeArquivo (nomeArq) == 0)
	{
		printf ("Erro na abertura do arquivo!");
	}
}
