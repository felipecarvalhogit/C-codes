#include <stdio.h>

//Tabela ASCII

int main ()
{
	int i;
	
	for (i=0;i<256;i++)
	{
		printf ("%d\t%c\n", i, i);
	}
}
