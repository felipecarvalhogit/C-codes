//copiar um arquivo para outro
#include <stdio.h>

//retorna 0 ou 1
int copiarArquivo (char origem[], char destino[])
{
	FILE *arq1, *arq2; 
	char caracter;

	arq1 = fopen (origem, "r");   
	arq2 = fopen (destino, "w");   
	
	//if ((arq1 == NULL) || (arq2 == NULL))
	if ((!arq1) || (!arq2))
	{
		return 0;
	}
	else
	{
		while (!feof(arq1))
		{
			fscanf (arq1, "%c", &caracter);
			fprintf (arq2, "%c", caracter);
		}
		
		fclose (arq1);	
		fclose (arq2);
		
		return 1;	
	}		
}

int main ()
{
	char nome1[20], nome2[20];
	
	printf ("Entre com o nome do arquivo a ser copiado: ");
	scanf ("%s", nome1);
	
	printf ("Entre com o nome do novo arquivo: ");
	scanf ("%s", nome2);
	
	if (copiarArquivo (nome1, nome2) == 0)
	{
		printf ("Erro na abertura do arquivo!");
	}
	else
	{
		printf ("Copia realizada com sucesso!");
	}
}
