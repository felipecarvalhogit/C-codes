//Armazenando os n�meros de 1 a 1000 no arquivo
#include <stdio.h>

int main ()
{
	FILE *arq;  //declarando o arquivo
	int i;
	
	arq = fopen ("numeros.txt", "w");   //abrindo o arquivo para escrita
	
	if (arq == NULL)
	{
		printf ("Erro na abertura do arquivo!");
	}
	else
	{
		for (i=1;i<=1000;i++)
		{
			fprintf (arq, "%d\n", i);
		}
		
		fclose (arq);		
	}
}
