//Lendo o conte�do de um arquivo, sabendo que o mesmo possui n�meros inteiros, um por linha
//e exibi-lo na tela
#include <stdio.h>

int main ()
{
	FILE *arq;  //declarando o arquivo
	int i;
	char nomeArq[20];
	
	//perguntando ao usu�rio o nome do arquivo
	printf ("Entre com o nome do arquivo: ");
	scanf ("%s", nomeArq);
	
	arq = fopen (nomeArq, "r");   //abrindo o arquivo para leitura
	
	if (arq == NULL)
	{
		printf ("Erro na abertura do arquivo!");
	}
	else
	{
		while (!feof(arq))
		{
			fscanf (arq, "%d\n", &i);
			printf ("%d\t", i);
		}
		
		fclose (arq);		
	}
}
