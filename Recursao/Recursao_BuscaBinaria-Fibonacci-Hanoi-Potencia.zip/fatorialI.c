/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
	
	Implementa��o de uma fun��o iterativa para o c�lculo de N!*/
	
#include <stdio.h>

//Fun��o fatorial
int fatorialI (int N)
{
	int i, fat = 1;
	
	for (i=2;i<=N;i++)
	{
		fat *= i;
	}
	
	return fat;
}

//main
int main ()
{
	int numero, resposta;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &numero);
	
	resposta = fatorialI (numero);
	
	printf ("\n%d! = %d", numero, resposta);
}
