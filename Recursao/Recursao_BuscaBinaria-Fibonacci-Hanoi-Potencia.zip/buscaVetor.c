/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
    
    Busca linear recursiva em um vetor
*/
	
#include <stdio.h>

int busca_aux (int v[], int pos, int tamanho, int numero)
{
	if (pos < tamanho)
	{
		if (v[pos] == numero)
		{
			return pos;
		}
		else
		{
			return busca (v, pos+1, tamanho, numero);
		}
	}
	
	return -1;
}

int busca (int v[], int tamanho, int numero)
{
	return busca_aux (v, 0, tamanho, numero);
}

//main
int main ()
{
	int vetor[10] = {5,1,9,23,12,56,0,7,1,9};
	int posicao, numero;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &numero);
	
	posicao = busca (vetor, 10, numero);	
	
	if (posicao == -1)
	{
		printf ("Elemento nao encontrado!");
	}
	else
	{
		printf ("Elemento encontrado na posicao %d", posicao);
	}
}
