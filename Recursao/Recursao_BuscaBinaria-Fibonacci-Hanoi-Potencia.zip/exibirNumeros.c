/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
*/
	
#include <stdio.h>

//Exibindo os n�meros de x at� 1, decrescentemente
void funcao1 (int x)
{
	if (x > 0)
	{
		printf ("%d ", x);
		funcao1 (x-1);
	}
}

//Exibindo os n�meros de 1 at� x, crescentemente
void funcao2 (int x)
{
	if (x > 0)
	{
		funcao2 (x-1);
		printf ("%d ", x);
	}
}

//main
int main ()
{
	int numero;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &numero);
	
	funcao1 (numero);
	
	printf ("\n\n");
	
	funcao2 (numero);
	
}
