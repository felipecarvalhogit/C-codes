/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
    
    Busca bin�ria recursiva em um vetor
*/
	
#include <stdio.h>

int busca_aux (int v[], int inicio, int fim, int numero)
{
	int meio;
	
	if (inicio <= fim)
	{
		meio = (inicio + fim)/2;
		
		printf ("Comparando %d com o elemento v[%d] = %d\n", numero, meio, v[meio]);
		
		if (v[meio] == numero)
		{
			return meio;
		}
		else
		{
			if (v[meio] > numero)
			{
				return busca_aux (v, inicio, meio-1, numero);
			}
			else
			{
				return busca_aux (v, meio+1, fim, numero);
			}
		}
	}
	
	return -1;
}

int buscaBinaria (int v[], int tamanho, int numero)
{
	return busca_aux (v, 0, tamanho-1, numero);
}

//main
int main ()
{
	int vetor[15] = {1,5,6,8,10,13,14,16,20,23,24,27,29,30,32};
	int posicao, numero;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &numero);
	
	posicao = buscaBinaria (vetor, 15, numero);	
	
	if (posicao == -1)
	{
		printf ("Elemento nao encontrado!");
	}
	else
	{
		printf ("Elemento encontrado na posicao %d", posicao);
	}
}
