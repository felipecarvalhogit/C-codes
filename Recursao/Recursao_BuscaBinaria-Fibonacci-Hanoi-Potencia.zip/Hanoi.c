/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
    
    Torres de Hanoi
*/
	
#include <stdio.h>

void Hanoi (int N, char O, char D, char aux)
{
	if (N > 0)
	{
		Hanoi (N-1, O, aux, D);
		printf ("%c -> %c\n", O, D);
		Hanoi (N-1, aux, D, O);
	}
}

//main
int main ()
{
	Hanoi (3,'A', 'C', 'B');
}
