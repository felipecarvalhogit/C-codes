/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
	
	Implementa��o de uma fun��o recursiva para o c�lculo de x elevado a y*/
	
#include <stdio.h>

//Fun��o fatorial
int potencia (int x, int y)
{
	if (y == 0)		//caso base da recurs�o
	{
		return 1;
	}
	else			//caso geral da recurs�o
	{
		return x * potencia (x, y-1);
	}
}

//main
int main ()
{
	int base, expoente, resposta;
	
	printf ("Entre com a base: ");
	scanf ("%d", &base);
	
	printf ("Entre com o expoente: ");
	scanf ("%d", &expoente);
	
	resposta = potencia (base, expoente);
	
	printf ("\n%d elevado a %d = %d", base, expoente, resposta);
}
