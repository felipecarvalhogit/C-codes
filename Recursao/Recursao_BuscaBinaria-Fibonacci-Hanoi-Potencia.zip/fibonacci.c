/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
    
    Determinar o n-�simo termo da sequ�ncia de Fibonacci
    
    S�rie: 1 1 2 3 5 8 13 ...
*/
	
#include <stdio.h>

int fibonacciR (int N)
{
	if (N < 3)   //caso base: verificando se � o 1� ou 2� elementos
	{
		return 1;
	}
	else		 //caso geral
	{
		return fibonacciR (N-1) + fibonacciR (N-2);
	}	
}


int fibonacciI (int N)
{
	int i, a, b, c;
	
	if (N < 3)   
	{
		return 1;
	}
	else
	{
		a = b = 1;
		for (i=3;i<=N;i++)
		{
			c = a + b;
			a = b;
			b = c;
		}
		
		return c;
	}
}


//main
int main ()
{
	int numero;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &numero);
	
	printf ("Chamando a fun��o iterativa: %d\n", fibonacciI (numero));
	
	system ("pause");
	
	printf ("\n\nChamando a fun��o recursiva: %d\n", fibonacciR (numero));
}
