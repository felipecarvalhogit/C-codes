/*  AL2 - Professor Leonardo Vianna
    Aula de 10/04/2017
	
	Implementa��o de uma fun��o recursiva para o c�lculo de N!*/
	
#include <stdio.h>

//Fun��o fatorial
int fatorialR (int N)
{
	if (N == 0)		//caso base da recurs�o
	{
		return 1;
	}
	else			//caso geral da recurs�o
	{
		return N * fatorialR (N-1);
	}
}

//main
int main ()
{
	int numero, resposta;
	
	printf ("Entre com um numero: ");
	scanf ("%d", &numero);
	
	resposta = fatorialR (numero);
	
	printf ("\n%d! = %d", numero, resposta);
}
