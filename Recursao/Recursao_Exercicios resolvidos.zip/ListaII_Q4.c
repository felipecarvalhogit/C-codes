/*Quest�o 04: Pede-se a implementa��o de uma fun��o recursiva que exiba os n primeiros 
termos de uma PG (Progress�o Geom�trica), onde a1 � o seu primeiro termo e q a raz�o.*/

#include <stdio.h>

void PG (int N, int a1, int q)
{
	if (N > 0)
	{
		printf ("%d ", a1);
		PG (N-1,a1*q,q);
	}
}

int main ()
{
	PG (5, 2, 3);
}
