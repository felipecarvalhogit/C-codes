/*Quest�o 02: Desenvolver uma fun��o recursiva que exiba todos os m�ltiplos do n�mero N, 
inferiores ao valor V.*/

#include <stdio.h>

void multiplos_aux (int N, int V, int contador)
{
	if (contador < V)  //caso geral
	{
		printf ("%d ", contador);

		multiplos_aux (N, V, contador+N);
	}
	
	//Caso base impl�cito: contador >= V
}

void multiplos (int N, int V)
{
	multiplos_aux (N, V, 0);
}

int main ()
{
	multiplos (10, 1000);
}
