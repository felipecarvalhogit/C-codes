/*Quest�o 05: Dada uma string s, desenvolver uma fun��o recursiva que determine se s � ou 
n�o um pal�ndromo.*/

#include <stdio.h>

int palindromo_aux (char *s, int inf, int sup)
{
	if (inf < sup)
	{
		if (s[inf] == s[sup])
		{
			return palindromo_aux (s, inf+1, sup-1);
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 1;
	}
}

//int palindromo (char s[])
int palindromo (char *s)
{
	return palindromo_aux (s,0,strlen(s)-1);
}

int main ()
{
	int p = palindromo ("TESTE");
	
	printf ("Resposta = %d", p);  
}
