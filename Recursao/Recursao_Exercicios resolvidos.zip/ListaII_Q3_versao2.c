/*Quest�o 03: Fazer uma fun��o recursiva que, dado um n�mero inteiro N, exiba o mesmo na 
base 2 (bin�ria).*/

#include <stdio.h>

void binario_aux (int N)
{
	if (N > 0)
	{
		binario_aux (N/2);
		printf ("%d", N%2);
	}
}

void binario (int N)
{
	if (N == 0)
	{
		printf ("0");
	}
	else
	{
		if (N < 0)
		{
			printf ("Valor invalido!");
		}
		else
		{
			binario_aux (N);
		}
	}
}

int main ()
{
	binario (50);
}
