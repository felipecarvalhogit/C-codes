/*Quest�o 06: Pede-se a implementa��o de uma fun��o que, dadas uma palavra P e uma letra L, 
remova de P todas as ocorr�ncias de L.*/

#include <stdio.h>

void remover (char *p, char l)
{
	int i, k=0;
	char *aux;
	
	aux = (char*) malloc (sizeof(char)*(strlen(p)+1));
	
	for (i=0; i<=strlen(p); i++)
	{
		if (p[i] != l)
		{
			aux[k++] = p[i];
		}
	}
	
	strcpy (p,aux);
}


int main ()
{
	 char s[10];
	 
	 strcpy (s, "PROGRAMACAO");
	 
	 remover (s, 'A');
	 
	 printf ("%s", s);
}
