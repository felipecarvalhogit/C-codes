/*
AL2 - Aula de 03/04/3017
Lista de Exerc�cios I - Matrizes

QUEST�O 04:
Fazer uma fun��o que, dada uma matriz M6�6, determine se ela � 
sim�trica.
*/

#include <stdio.h>

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define X 3

void matrizT(int reais[X][X], int trans[X][X])
{	
	int i, j;
	
	for (i=0;i<X;i++)
	{
		for(j=0;j<X;j++)
		{
			trans[j][i]=reais[i][j];
		}
	}
}

int simetria(int reais[X][X])
{
	int i,j;
	int trans[X][X];
	
	matrizT(reais, trans);
	
	for (i=0;i<X;i++)
	{
		for(j=0;j<X;j++)
		{
			if (reais[i][j]!=trans[i][j]){
				return 0;
			}		
		}
	}
	return 1;
}

void main()
{
	int reais[X][X]={{1,2,4},{2,3,7},{4,7,10}};
	int i,j,teste;
	
	//srand(time(NULL));
	
	/*for (i=0;i<X;i++)
	{
		for (j=0;j<X;j++)
		{
			reais[i][j] = rand()%10;
			printf("%d ", reais[i][j]);
		}
		printf("\n");
	}*/
	for (i=0;i<X;i++)
	{
		for (j=0;j<X;j++)
		{
			printf("%d ", reais[i][j]);
		}
		printf("\n");
	}
printf("\n\n");
	
teste=simetria(reais);



if(teste==1){
	printf("Eh simetrica!");
}
else
printf ("Nao eh simetrica!");

printf("\n\n");

	
}

