/*
AL2 - Aula de 03/04/3017
Lista de Exerc�cios I - Matrizes
Desenvolver uma fun��o que gere a seguinte matriz M5x5:

	1	2	3	4	5	
	2	3	4	5	6	
	3	4	5	6	7	
	4	5	6	7	8	
	5	6	7	8	9	

*/

#include <stdio.h>
#define l 5
#define c 5

int main(){
	int m[l][c];
	int i, j;
	
	for(i=0;i<l;i++){
		
		for(j=0;j<c;j++){
			if(i==0){
				m[i][j] = j+1;
			}else{
				m[i][j] = m[i-1][j]+1;
			}	
		}
		
	}
	
	for(i=0;i<l;i++){
		
		for(j=0;j<c;j++){
			printf("%d ",m[i][j]);
		}
		printf("\n");
	}
		
}
