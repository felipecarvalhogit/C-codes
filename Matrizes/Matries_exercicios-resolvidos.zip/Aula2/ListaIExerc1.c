/*
AL2 - Aula de 03/04/3017
Lista de Exerc�cios I - Matrizes
QUEST�O 01:
Fa�a um fun��o que, dada uma matriz M8�5 de reais, gere a matriz Mt, 
sua transposta.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define X 8
#define Y 5

void matrizT(float reais[X][Y], float trans[Y][X])
{
	
	int i, j;
	
	for (i=0;i<X;i++)
	{
		for(j=0;j<Y;j++)
		{
			trans[j][i]=reais[i][j];
		}
	}
}

void main()
{
	float reais[X][Y], trans[Y][X];
	int i,j;
	
	srand(time(NULL));
	
	for (i=0;i<X;i++)
	{
		for (j=0;j<Y;j++)
		{
			reais[i][j] = rand()%10;
			printf("%.1f ", reais[i][j]);
		}
		printf("\n");
	}

	matrizT(reais, trans);
	printf("\n\n");

	for (i=0;i<Y;i++)
	{
		for (j=0;j<X;j++)
		{
			printf("%.1f ", trans[i][j]);
		}
		printf("\n");
	}	
}
