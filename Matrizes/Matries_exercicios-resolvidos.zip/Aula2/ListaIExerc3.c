/*
AL2 - Aula de 03/04/3017
Lista de Exerc�cios I - Matrizes
Desenvolver uma fun��o que gere a seguinte matriz M5x5:

	1	2	3	4	5	
	2	3	4	5	6	
	3	4	5	6	7	
	4	5	6	7	8	
	5	6	7	8	9	

*/

int montaMatriz(int m[5][5])
{
	int i,j;
	
	for (i=0;i<5;i++) 
	{	
		for (j=0;j<5;j++) 
		{	
			m[i][j] = i+j+1;
    	}
	}
}

int mostraMatriz(int m[5][5])
{
	int i,j;
	
	printf("\n Matriz M (5x5):\n\n");
	
	for (i=0;i<5;i++) 
	{	
		for (j=0;j<5;j++) 
		{	
			printf (" %d ", m[i][j]); 
    	}
		printf ("\n\n"); 
	}
}

int main()
{    
	int m[5][5];
    
	montaMatriz(m);
	mostraMatriz(m);
}
