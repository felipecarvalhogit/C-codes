/*
AL2 - Aula de 03/04/3017
Lista de Exerc�cios I - Matrizes

QUEST�O 05:
Implementar uma fun��o que, dada uma matriz M10�8, gere um vetor V 
de tamanho 8, onde cada elemento do vetor consiste na soma dos 
elementos de uma coluna de M. Ou seja, o elemento V[1] consiste na 
soma dos elementos da primeira coluna de M, o elemento V[2] consiste 
na soma dos elementos da segunda coluna de M, e assim por diante.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define L 10
#define C 8

void geraMatriz(int mat[L][C]) // Gera a matriz com 10 linhas e 8 colunas
{
	int i,j;
    srand(time(NULL));
	
	for (i=0;i<L;i++) 
	{	
		for (j=0;j<C;j++) 
			mat[i][j] = rand()%10;
	}
}

void mostraMatriz(int mat[L][C]) // Exibe a matriz gerada
{
	int i,j;

	for (i=0;i<L;i++) 
	{	
		for (j=0;j<C;j++) 
			printf (" %d ",mat[i][j]); 
    		printf ("\n\n"); 
	}
}

void geravetor(int mat[L][C], int vetorB[C])
{
	int i,j,somacol=0;
	
	for (j=0;j<C;j++) 
	{	
		for (i=0;i<L;i++) 
		{
			somacol+=mat[i][j];
		}	
		vetorB[j]=somacol;
		somacol=0;
	}
}

void mostravetor(int vetor[C])
{
    int i;
	
	printf("\n--------------------------------\n");
	printf("  Pos.  Soma");
	printf("\n--------------------------------\n");
	
	for(i=0;i<C;i++) 
	{
		printf("\n");
		printf("   %d  -  %2d",i,vetor[i]);
		printf("\n");
	}
}

int main() // Fun��o principal
{
	int M[L][C],V[C];
	
	geraMatriz(M);
	printf("\n--------------------------------\n");
	printf("\n Matriz M (10x8):\n\n");	
	mostraMatriz(M);
	
	geravetor(M,V);
	printf("\n--------------------------------\n");
	printf("\n Vetor V (8): \n\n");
	mostravetor(V);
}

