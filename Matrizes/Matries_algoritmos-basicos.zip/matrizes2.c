#include <stdio.h>

#define L 4
#define C 3

int main ()
{
	int m[L][C];
	int i, j, cont, numero, coluna;
	
	//Ler elementos para uma matriz
	for (i=0;i<L;i++)
	{
		for (j=0;j<C;j++)
		{
			printf ("Entre com um n�mero: ");
			scanf ("%d", &m[i][j]);
		}
	}
	
	//Exbindo os elementos da matriz
	for (i=0;i<L;i++)
	{
		for (j=0;j<C;j++)
		{
			printf ("%d ", m[i][j]);
		}
		printf ("\n");
	}
	
	
	//Verificar se um n�mero fornecido pelo usu�rio encontra-se 
	//na coluna x da matriz
	printf ("\n\nQual n�mero ser� pesquisado?");
	scanf ("%d", &numero);
	
	printf ("Em qual coluna?");
	scanf ("%d", &coluna);
	
	cont = 0;
	
	for (i=0;i<L;i++)
	{
		if (numero == m[i][coluna])
		{
			cont++; 			
		}
	}
	
	printf ("O n�mero %d apareceu %d vez(es) na coluna %d da matriz\n\n", numero, cont, coluna);
}
