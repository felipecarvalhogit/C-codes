#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define L 5

int main ()
{
	int m[L][L], n[L][L], s[L][L];
	int i, j;
	
	srand(time(NULL));
	
	//preenchendo a matriz M com n�meros aleat�rios
	for (i=0;i<L;i++)
	{
		for (j=0;j<L;j++)
		{
			m[i][j] = rand()%10;
		}
	}
	
	//preenchendo a matriz N com n�meros aleat�rios
	for (i=0;i<L;i++)
	{
		for (j=0;j<L;j++)
		{
			n[i][j] = rand()%10;
		}
	}

	//Somando as matrizes: S = M + N
	for (i=0;i<L;i++)
	{
		for (j=0;j<L;j++)
		{
			s[i][j] = m[i][j] + n[i][j];
		}
	}
		
	//Exbindo os elementos da matriz
	for (i=0;i<L;i++)
	{
		for (j=0;j<L;j++)
		{
			printf ("%d ", m[i][j]);
		}
		printf ("\n");
	}
	
	printf ("\n");
	
	for (i=0;i<L;i++)
	{
		for (j=0;j<L;j++)
		{
			printf ("%d ", n[i][j]);
		}
		printf ("\n");
	}
	
	printf ("\n");
	
	for (i=0;i<L;i++)
	{
		for (j=0;j<L;j++)
		{
			printf ("%2d ", s[i][j]);
		}
		printf ("\n");
	}
	
}
