#include <stdio.h>

#define L 4
#define C 3

int main ()
{
	int m[L][C];
	int i, j, cont, numero;
	
	//Ler elementos para uma matriz
	for (i=0;i<L;i++)
	{
		for (j=0;j<C;j++)
		{
			printf ("Entre com um n�mero: ");
			scanf ("%d", &m[i][j]);
		}
	}
	
	//Verificar se um n�mero fornecido pelo usu�rio encontra-se na matriz
	printf ("Qual n�mero ser� pesquisado?");
	scanf ("%d", &numero);
	
	cont = 0;
	
	for (i=0;i<L;i++)
	{
		for (j=0;j<C;j++)
		{
			if (numero == m[i][j])
			{
				cont++; 
			}
		}
	}
	
	printf ("O n�mero %d apareceu %d vez(es) na matriz\n\n", numero, cont);
}
