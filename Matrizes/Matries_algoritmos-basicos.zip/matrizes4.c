#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define X 5
#define Y 4
#define Z 7

int main ()
{
	int m[X][Y], n[Y][Z], mult[X][Z];
	int i, j, k;
	
	srand(time(NULL));
	
	//preenchendo a matriz M com n�meros aleat�rios
	for (i=0;i<X;i++)
	{
		for (j=0;j<Y;j++)
		{
			m[i][j] = rand()%10;
		}
	}
	
	//preenchendo a matriz N com n�meros aleat�rios
	for (i=0;i<Y;i++)
	{
		for (j=0;j<Z;j++)
		{
			n[i][j] = rand()%10;
		}
	}

	//Multiplicando as matrizes: mult = M * N
	for (i=0;i<X;i++)
	{
		for (j=0;j<Z;j++)
		{
			//calcular mult[i][j]
			mult[i][j] = 0;
			for (k=0;k<Y;k++)
			{
				mult[i][j] += m[i][k] * n[k][j];
			}
		}
	}
		
	//Exbindo os elementos da matriz
	for (i=0;i<X;i++)
	{
		for (j=0;j<Y;j++)
		{
			printf ("%d ", m[i][j]);
		}
		printf ("\n");
	}
	
	printf ("\n");
	
	for (i=0;i<Y;i++)
	{
		for (j=0;j<Z;j++)
		{
			printf ("%d ", n[i][j]);
		}
		printf ("\n");
	}
	
	printf ("\n");
	
	for (i=0;i<X;i++)
	{
		for (j=0;j<Z;j++)
		{
			printf ("%3d ", mult[i][j]);
		}
		printf ("\n");
	}
	
}
